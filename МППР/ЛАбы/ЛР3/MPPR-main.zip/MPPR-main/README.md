# Репозиторий курса Методы Поддержки Принятия Решений 
7 семестр ИУ5

[Лабораторная работа №3](https://github.com/iu5git/MPPR/blob/main/notebooks/Lab3.ipynb)

[Каталог для тестирования модели из лабораторной работы №3](https://github.com/iu5git/MPPR/tree/main/ONNX)

[Домашнее задание №3](https://github.com/iu5git/MPPR/blob/main/notebooks/homework3.md)
